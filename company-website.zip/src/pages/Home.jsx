import { useEffect, useMemo, useState } from "react";
import styles from "./Home.module.scss";

import CategoryStrip from "../features/categories/CategoryStrip.jsx";
import categories from "../features/categories/categories.mock.js";

import { getProducts } from "../services/productsService.js";
import ProductsCarousel from "../features/products/ProductsCarousel.jsx";

import AboutStrip from "../components/sections/AboutStrip.jsx";

export default function Home() {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(false);
    const [activeCategoryId, setActiveCategoryId] = useState(null);

    useEffect(() => {
        let alive = true;

        const run = async () => {
            setLoading(true);
            try {
                const res = await getProducts();
                if (!alive) return;
                setProducts(Array.isArray(res) ? res : []);
            } catch {
                if (!alive) return;
                setProducts([]);
            } finally {
                if (alive) setLoading(false);
            }
        };

        run();

        return () => {
            alive = false;
        };
    }, []);

    const categoryItems = useMemo(() => {
        return Array.isArray(categories) ? categories : [];
    }, []);

    return (
        <div className={styles.page}>
            {/* Hero بالا (اون عکس اول صفحه که گفتی باید اول باشه) */}
            <section className={styles.hero}>
                <img
                    className={styles.heroImg}
                    src="/images/banners/hero.jpg"
                    alt="Kamchin hero"
                    loading="eager"
                />
            </section>

            {/* دسته‌بندی‌ها مثل عکس new */}
            <section className={styles.section}>
                <CategoryStrip
                    title="محصولات کامچین"
                    items={categoryItems}
                    onSelect={(id) => setActiveCategoryId(id)}
                />
            </section>

            {/* لیست محصولات: بدون دکمه‌های چپ/راست، hover سبز، کلیک = جزئیات */}
            <section className={styles.section}>
                <ProductsCarousel
                    title={loading ? "در حال دریافت محصولات..." : "محصولات"}
                    products={products}
                    filterCategoryId={activeCategoryId}
                />
            </section>

            {/* درباره کامچین پایین بمونه */}
            <section className={styles.section}>
                <AboutStrip />
            </section>
        </div>
    );
}
