import repsMock from "../data/reps.mock.js";

export async function getReps() {
    return repsMock;
}
